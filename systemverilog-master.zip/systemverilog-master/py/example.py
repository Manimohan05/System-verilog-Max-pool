a = True
b = False
c = a and b
print(c)

a = True
b = True
print(c)

s1 = 0
for i in range(6):
    s1 = s1 + 1
    print(s1)

s2 = 255
for i in range(6):
    s2 = s2 - 1
    print(s2)
